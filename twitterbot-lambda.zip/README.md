# RandomNameGenerator On AWS Lambda

This is a random name generator written in Haskell deployed to AWS Lambda.

You will need [Stack](https://docs.haskellstack.org/en/stable/README/#how-to-install) to build and run locally.

## Usage

```
make build
```

Then upload `twitterbot-lambda/twitterbot.zip` to your AWS lambda.

